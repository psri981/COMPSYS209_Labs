/*
 * lab5 prelab.c
 *
 * Created: 27/09/2021 11:25:08 PM
 * Author : Harry_Version.2
 */ 

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
    /* Replace with your application code */
	
		//setting PORTB as input
		DDRB = 0xFF;
		PORTB = 0x00;
		
		//setting PORTC and PORTD as output
		DDRC = 0x00;
		PORTC = 0x00;
		
		DDRD = 0x00;
		PORTD = 0x00;
		
		
		
    while (1) 
    {
		//PORTB LED ON
		PORTB = 0b00100000;
		_delay_ms(375);
		
		//PORTB LED OFF
		PORTB = 0b00000000;
		_delay_ms(125);
    }
}

